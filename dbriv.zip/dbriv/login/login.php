<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Login / Register panel effects</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Bitter:400,700'>
<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.0.9/css/all.css'><link rel="stylesheet" href="./login.css">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">
</head>
<body>
  <?php include '../assets/php/navbar.php' ?>

<!-- partial:index.partial.html -->
<div class='wrapper' id='wrapper'>
  <p class='announcement'>  <a href="https://front.codes/" class="logo" target="_blank">
    <img src="./assets/REVIEW_HUB_LOGO.png" alt="">
  </a></p>
  <div class='card-group' data-active-card='login' id='card-group'>
    <div class='transition-animation' id='transition-animation'></div>
    <div class='card card-login' id='login'>
      <h1 class='title'>LOGIN</h1>
      <hr>
      <p class='disclaimer'>Now it's time to access <br> your account</p>
      <form id='login-form'>
        <div class='input-group'>
          <input id='name' name='name' onkeyup="this.setAttribute('value', this.value);" type='text' value=''>
          <label for='name'>Username</label>
        </div>
        <div class='input-group'>
          <input id='password' name='password' onkeyup="this.setAttribute('value', this.value);" type='password' value=''>
          <label for='password'>Password</label>
        </div>
        <button class='btn-default' data-action='submit' type='button'>Submit <span class="fas fa-arrow-right"></span></button>
      </form>
      <div class='card-footer'>
        <p>Don't have an account yet? <br> Click on the button below</p>
        <button class='btn-default btn-invert' data-action='register' id='btn-register' type='javascript:void(0)'>Register <span class="fas fa-check"></span></button>
      </div>
    </div>
    <div class='card card-register' id='register'>
      <h1 class='title'>REGISTER</h1>
      <hr>
      <p class='disclaimer'>Now it's time to create <br> your account</p>
      <form id='register-form'>
        <div class='input-group'>
          <input id='name-reg' name='name-reg' onkeyup="this.setAttribute('value', this.value);" type='text' value=''>
          <label for='name-reg'>Your username</label>
        </div>
        <div class='input-group'>
          <input id='password-reg' name='password-reg' onkeyup="this.setAttribute('value', this.value);" type='password' value=''>
          <label for='password-reg'>Your password</label>
        </div>
        <div class='input-group'>
          <input id='password-reg-cf' name='password-reg-cf' onkeyup="this.setAttribute('value', this.value);" type='password' value=''>
          <label for='password-reg-cf'>Confirm your password</label>
        </div>
        <button class='btn-default' data-action='submit' type='button'>Submit <span class="fas fa-check"></span></button>
      </form>
      <div class='card-footer'>
        <p>Already have an account? <br> Click on the button below</p>
        <button class='btn-default btn-invert' data-action='login' id='btn-register' type='javascript:void(0)'>Login <span class="fas fa-arrow-right"></span></button>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  <script  src="./login.js"></script>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js'></script><script  src="./script.js"></script>

<script type="text/javascript">
  
</script>
</body>
</html>
